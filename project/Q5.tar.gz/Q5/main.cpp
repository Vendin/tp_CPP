#include "dialog.h"
#include <QApplication>
#include <menu.h>
#include "ui_dialog.h"
 #include <QObject>
#include <QtGui>
#include <dialog.h>


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Dialog *w;
    w = new Dialog();
    //w->resize(775, 652);
    w->show();
    Menu *aa = new Menu();
  //  aa->resize(575, 452);
  //  aa->setFont(QFont("Times", 20, QFont::Bold));
  //d6  aa->show();

    return a.exec();
}
