#ifndef PLAYER_H
#define PLAYER_H

#include <QGraphicsScene>
#include <QGraphicsItem>
#include "myitem.h"

namespace Ui {
class Player;
}


class Player //: QGraphicsItem
{
private:

public:
    MyItem *particle_black;
    MyItem *particle1_white;
    Player(int x_black, int y_black, int x_white, int y_white);
    void move_event(int phase);
    void change_speed(int a, int b);
    bool zero_speed();
    template<class T> friend bool incl(T left1, T right1, T left2, T right2);
};

#endif // PLAYER_H
